import { SignUp } from "@clerk/nextjs";

interface Props {

}

const Page = ({}: Props) => {
  return (
    <SignUp />
  );
};

export default Page;