
type Props = {

}
const Page = ({}: Props) => {
    

    return (
        <>
            
        </>
    );
};

export default Page;